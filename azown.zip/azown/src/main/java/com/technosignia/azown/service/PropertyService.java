package com.technosignia.azown.service;

public class PropertyService {

}
