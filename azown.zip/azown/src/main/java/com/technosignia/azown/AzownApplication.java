package com.technosignia.azown;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzownApplication {

	public static void main(String[] args) {
		SpringApplication.run(AzownApplication.class, args);
	}

}
