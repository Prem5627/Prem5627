package com.technosignia.azown.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Address {
	
	@Id
	Long id;
	
	String street;
	
	String landmark;
	
	Long pincode;
	
	
	

}
