package com.technosignia.azown.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technosignia.azown.entity.Owner;
import com.technosignia.azown.repository.OwnerRepository;

@Service
public class OwnerService {
	
	@Autowired
	OwnerRepository ownerRepository;
	
	
	public Owner createOwnerDetails(Owner owner) {
		
		return ownerRepository.save(owner);
	}

}
