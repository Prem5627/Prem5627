package com.technosignia.azown.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PropertyController {

	
	
}
