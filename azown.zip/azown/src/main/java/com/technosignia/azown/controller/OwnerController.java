package com.technosignia.azown.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technosignia.azown.entity.Owner;
import com.technosignia.azown.service.OwnerService;


@RestController
public class OwnerController {
	
	@Autowired
	OwnerService ownerService;
	

	@PostMapping("/owner")
	public Owner createOwnerDetails(@RequestBody Owner owner) {
		
		return ownerService.createOwnerDetails(owner);
		
	}

}
