package com.technosignia.azown.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technosignia.azown.entity.Property;

public interface PropertyService  extends JpaRepository<Property,Long>{
	

}
